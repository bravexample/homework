// A header for cheating in Heros of Jinyong

#ifndef CHEAT_H
#define CHEAT_H

#include <stddef.h>

void ChangeAttributes(FILE *);
void ChangeItems(FILE *);
void ChangeArts(FILE *);
void ChangeData(FILE *);

#endif